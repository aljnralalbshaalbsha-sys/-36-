<?php
if(file_exists(__DIR__.'/installed.lock')) die("تم إعداد المنصة بالفعل. احذف installed.lock فقط إذا أردت إعادة الإعداد.");
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $h=trim($_POST['host']);$n=trim($_POST['name']);$u=trim($_POST['user']);$p=$_POST['pass'];
 try{
  $pdo=new PDO("mysql:host=$h;charset=utf8mb4",$u,$p,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS `$n` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  $pdo->exec("USE `$n`");
  $pdo->exec("CREATE TABLE IF NOT EXISTS students(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,father VARCHAR(100) NOT NULL,grandfather VARCHAR(100) NOT NULL,student_no VARCHAR(50) NOT NULL,parent_phone VARCHAR(30) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS lessons(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,access_code VARCHAR(100) NOT NULL UNIQUE,video_url TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
  file_put_contents(__DIR__.'/db_config.json',json_encode(['host'=>$h,'name'=>$n,'user'=>$u,'pass'=>$p],JSON_UNESCAPED_UNICODE));
  file_put_contents(__DIR__.'/installed.lock','ok');
  header("Location: admin/login.php");exit;
 }catch(Exception $e){$msg="فشل الاتصال: ".$e->getMessage();}
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>إعداد المنصة</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="box"><h1>إعداد المنصة لأول مرة</h1><p>اكتب بيانات MySQL التي يعطيها لك الاستضافة.</p>
<?php if($msg): ?><p class="err"><?=htmlspecialchars($msg)?></p><?php endif; ?>
<form method="post"><input name="host" value="localhost" placeholder="Database Host" required><input name="name" placeholder="Database Name" required><input name="user" placeholder="Database User" required><input name="pass" type="password" placeholder="Database Password"><button>إنشاء قاعدة البيانات وتجهيز المنصة</button></form></div></body></html>