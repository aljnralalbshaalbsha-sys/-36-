<?php session_start();if(empty($_SESSION['admin'])){header("Location:login.php");exit;}require __DIR__.'/../config.php';
if(isset($_POST['add'])){$s=$pdo->prepare("INSERT INTO lessons(title,access_code,video_url) VALUES(?,?,?)");$s->execute([$_POST['title'],$_POST['code'],$_POST['video']]);}
$students=$pdo->query("SELECT * FROM students ORDER BY id DESC")->fetchAll();$lessons=$pdo->query("SELECT * FROM lessons ORDER BY id DESC")->fetchAll();?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>لوحة الإدارة</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="box wide"><h1>لوحة الإدارة</h1>
<h2>إضافة درس</h2><form method="post"><input name="title" placeholder="اسم الدرس" required><input name="code" placeholder="كود الدرس" required><input name="video" placeholder="رابط الفيديو" required><button name="add">إضافة</button></form>
<h2>الطلاب</h2><?php foreach($students as $s):?><div class="row"><?=htmlspecialchars($s['name'])?> — <?=htmlspecialchars($s['student_no'])?> — <?=htmlspecialchars($s['parent_phone'])?></div><?php endforeach;?>
<h2>الدروس</h2><?php foreach($lessons as $l):?><div class="row"><?=htmlspecialchars($l['title'])?> — الكود: <?=htmlspecialchars($l['access_code'])?></div><?php endforeach;?>
<a href="logout.php">خروج الإدارة</a></div></body></html>