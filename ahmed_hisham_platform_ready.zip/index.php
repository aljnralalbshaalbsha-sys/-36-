<?php
session_start();
if (file_exists(__DIR__.'/installed.lock')) {
    header("Location: lessons.php"); exit;
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>منصة مستر أحمد هشام</title><link rel="stylesheet" href="assets/style.css"></head>
<body><div class="box"><h1>منصة مستر أحمد هشام</h1><p>تسجيل دخول الطالب</p>
<form action="register.php" method="post">
<input name="name" placeholder="الاسم" required>
<input name="father" placeholder="اسم الأب" required>
<input name="grandfather" placeholder="اسم الجد" required>
<input name="student_no" placeholder="رقم الطالب" required>
<input name="parent_phone" placeholder="رقم ولي الأمر" required>
<button>دخول المنصة</button></form>
<a href="admin/login.php">دخول الإدارة</a></div></body></html>