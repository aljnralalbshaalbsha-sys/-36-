<?php
require __DIR__.'/config.php'; session_start();
if(empty($_SESSION['student_id'])){header("Location:index.php");exit;}
$lessons=$pdo->query("SELECT * FROM lessons ORDER BY id DESC")->fetchAll();
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $code=trim($_POST['code']??'');
 $q=$pdo->prepare("SELECT * FROM lessons WHERE access_code=?");
 $q->execute([$code]); $lesson=$q->fetch();
 if($lesson){$_SESSION['open_lesson']=$lesson['id']; header("Location: lessons.php"); exit;}
 $msg='الكود غير صحيح';
}
$open=null;
if(!empty($_SESSION['open_lesson'])){
 $q=$pdo->prepare("SELECT * FROM lessons WHERE id=?");$q->execute([$_SESSION['open_lesson']]);$open=$q->fetch();
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الدروس</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="box">
<h1>الدروس</h1><form method="post"><input name="code" placeholder="اكتب كود الدرس" required><button>فتح الدرس</button></form>
<?php if($msg): ?><p class="err"><?=htmlspecialchars($msg)?></p><?php endif; ?>
<?php if($open): ?><div class="lesson"><h2><?=htmlspecialchars($open['title'])?></h2><div class="video"><iframe src="<?=htmlspecialchars($open['video_url'])?>" allowfullscreen></iframe></div></div><?php endif; ?>
<a href="logout.php">تسجيل الخروج</a></div></body></html>