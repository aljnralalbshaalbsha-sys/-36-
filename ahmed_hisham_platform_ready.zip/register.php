<?php
require __DIR__.'/config.php';
session_start();
$stmt=$pdo->prepare("INSERT INTO students(name,father,grandfather,student_no,parent_phone) VALUES(?,?,?,?,?)");
$stmt->execute([$_POST['name'],$_POST['father'],$_POST['grandfather'],$_POST['student_no'],$_POST['parent_phone']]);
$_SESSION['student_id']=$pdo->lastInsertId();
header("Location: lessons.php"); exit;