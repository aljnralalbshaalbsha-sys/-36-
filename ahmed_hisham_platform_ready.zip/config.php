<?php
if(!file_exists(__DIR__.'/installed.lock')){header("Location: setup.php");exit;}
$c=json_decode(file_get_contents(__DIR__.'/db_config.json'),true);
try{$pdo=new PDO("mysql:host=".$c['host'].";dbname=".$c['name'].";charset=utf8mb4",$c['user'],$c['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(Exception $e){die("فشل الاتصال بقاعدة البيانات. افتح setup.php لإعادة الإعداد.");}
?>